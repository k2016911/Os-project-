gcc main.c pbPlots.c supportLib.c -fopenmp -lpthread -lm
./a.out
